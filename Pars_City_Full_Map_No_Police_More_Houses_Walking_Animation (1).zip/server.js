'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Server } = require('socket.io');
const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const ROOM = 'PARS-CITY';
const MAX_PLAYERS = Number(process.env.MAX_PLAYERS || 35);
const players = new Map();
const dataPath = path.join(ROOT, 'player-data.json');
// Pars City fresh-start release: intentionally reset all server profiles once for this release.
// This clears saved progress so every player starts from the same clean state.
let profiles = {};
try { fs.writeFileSync(dataPath, JSON.stringify(profiles)); } catch (e) { console.warn('Could not initialize fresh player data:', e.message); }
function saveProfiles() { const tmp = dataPath + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(profiles)); fs.renameSync(tmp, dataPath); }
function safeProfileId(v) { return /^[a-zA-Z0-9_-]{12,80}$/.test(String(v || '')) ? String(v) : null; }
function cleanProfile(v) { if (!v || typeof v !== 'object') return null; return { money: Math.max(0, Math.min(1000000000, Number(v.money) || 0)), inventory: Array.isArray(v.inventory) ? v.inventory.filter(x => typeof x === 'string').slice(0,50) : [], ownedCars: Array.isArray(v.ownedCars) ? [...new Set(v.ownedCars.filter(x => ['pride','blueTruck','pars','sport','suv','classic','benz2025'].includes(x)))].slice(0,20) : ['pride'], carType: ['pride','blueTruck','pars','sport','suv','classic','benz2025'].includes(v.carType) ? v.carType : 'pride', playerPos: v.playerPos && Number.isFinite(v.playerPos.x) && Number.isFinite(v.playerPos.z) ? {x:Math.max(-500,Math.min(500,v.playerPos.x)), y:0, z:Math.max(-500,Math.min(500,v.playerPos.z))} : {x:0,y:0,z:0}, droppedItems: Array.isArray(v.droppedItems) ? v.droppedItems.filter(d=>d && typeof d.name==='string' && Number.isFinite(d.x) && Number.isFinite(d.z)).slice(0,100) : [] }; }
const indexPath = path.join(ROOT, 'index.html');
const server = http.createServer((req, res) => {
  const pathname = new URL(req.url, 'http://localhost').pathname;
  if (pathname === '/health') {
    res.writeHead(200, {'content-type':'application/json; charset=utf-8','cache-control':'no-store'});
    return res.end(JSON.stringify({ok:true,game:'Pars City',server:ROOM,players:players.size,maxPlayers:MAX_PLAYERS}));
  }
  if (pathname === '/' || pathname === '/index.html') {
    res.writeHead(200, {'content-type':'text/html; charset=utf-8','cache-control':'no-store'});
    return fs.createReadStream(indexPath).pipe(res);
  }
  res.writeHead(404, {'content-type':'text/plain; charset=utf-8'}); res.end('Not found');
});
const io = new Server(server, { cors: { origin: '*' }, pingInterval: 25000, pingTimeout: 20000, maxHttpBufferSize: 1e5 });
function safeName(v) { return String(v || 'بازیکن').replace(/[<>\u0000-\u001f]/g,'').trim().slice(0,20) || 'بازیکن'; }
function safePosition(p) {
  if (!p || !Number.isFinite(p.x) || !Number.isFinite(p.z) || !Number.isFinite(p.angle)) return null;
  return {x:Math.max(-500,Math.min(500,p.x)),z:Math.max(-500,Math.min(500,p.z)),angle:((p.angle%(Math.PI*2))+Math.PI*2)%(Math.PI*2),inCar:!!p.inCar,carType:String(p.carType||'pride').slice(0,24)};
}
io.on('connection', socket => {
  socket.data.joined = false;
  socket.data.lastMoveAt = 0;
  socket.on('joinRoom', data => {
    if (socket.data.joined) return;
    const requested = String((data && data.server) || ROOM);
    if (requested !== ROOM) return socket.emit('joinError', {message:'این سرور در دسترس نیست.'});
    if (players.size >= MAX_PLAYERS) return socket.emit('roomFull', {server:ROOM});
    socket.data.joined = true;
    socket.data.name = safeName(data && data.name);
    socket.data.profileId = safeProfileId(data && data.profileId) || ('guest_' + socket.id.replace(/[^a-zA-Z0-9_-]/g,''));
    socket.data.position = {x:0,z:0,angle:0,inCar:false,carType:'pride'};
    const player = {id:socket.id,name:socket.data.name,position:socket.data.position};
    players.set(socket.id,player);
    socket.join(ROOM);
    socket.emit('roomJoined',{room:ROOM,id:socket.id,players:[...players.values()]});
    socket.emit('profileData', { profileId: socket.data.profileId, profile: profiles[socket.data.profileId] || null });
    socket.to(ROOM).emit('playerJoined',player);
  });
  socket.on('saveProfile', data => {
    if (!socket.data.joined || !socket.data.profileId) return;
    const profile = cleanProfile(data); if (!profile) return;
    profiles[socket.data.profileId] = profile;
    try { saveProfiles(); socket.emit('profileSaved', { ok: true }); } catch (e) { socket.emit('profileSaved', { ok: false, message: 'ذخیره‌سازی سرور انجام نشد.' }); }
  });
  socket.on('move', data => {
    if (!socket.data.joined) return;
    const now = Date.now();
    if (now - socket.data.lastMoveAt < 45) return;
    socket.data.lastMoveAt = now;
    const position=safePosition(data); if(!position)return;
    socket.data.position=position;
    const player=players.get(socket.id); if(!player)return;
    player.position=position;
    socket.to(ROOM).emit('playerMoved',{id:socket.id,name:socket.data.name,position});
  });
  socket.on('disconnect',()=>{
    if(!players.has(socket.id)) return;
    players.delete(socket.id);
    socket.to(ROOM).emit('playerLeft',{id:socket.id});
  });
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Pars City online server listening on ${PORT}; room=${ROOM}; max=${MAX_PLAYERS}`));
